import { Request, Response, NextFunction } from 'express';
import { authService } from '../services/auth.service';
import { otpService } from '../services/otp.service';
import { passwordService } from '../services/password.service';
import { googleAuthService } from '../services/google-auth.service';
import { emailService } from '../services/email.service';
import {
  loginSchema,
  registerSchema,
  otpVerifySchema,
  passwordResetRequestSchema,
  passwordResetSchema,
} from '@alsaeed/shared';
import { UnauthorizedError } from '../utils/errors';

export const authController = {
  // ---------- BASIC AUTH ----------

  register: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const input = registerSchema.parse(req.body);
      const result = await authService.register(input);

      // Fire-and-forget side effects
      otpService.issue(result.user.id, 'EMAIL_VERIFICATION').catch(() => {});
      emailService.sendWelcome(result.user.email, result.user.firstName).catch(() => {});

      res.status(201).json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  login: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const input = loginSchema.parse(req.body);
      const result = await authService.login(input, {
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
      });
      res.json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  refresh: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const refreshToken = req.body.refreshToken || req.cookies?.refreshToken;
      if (!refreshToken) throw new UnauthorizedError('Missing refresh token');
      const result = await authService.refresh(refreshToken);
      res.json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  logout: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const refreshToken = req.body.refreshToken || req.cookies?.refreshToken;
      if (refreshToken) await authService.logout(refreshToken);
      res.json({ success: true, data: { message: 'Logged out' } });
    } catch (err) {
      next(err);
    }
  },

  me: async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.user) throw new UnauthorizedError();
      const user = await authService.getMe(req.user.userId);
      res.json({ success: true, data: user });
    } catch (err) {
      next(err);
    }
  },

  // ---------- OTP & EMAIL VERIFICATION ----------

  sendOtp: async (req: Request, res: Response, next: NextFunction) => {
    try {
      if (!req.user) throw new UnauthorizedError();
      const purpose = req.body.purpose || 'EMAIL_VERIFICATION';
      const result = await otpService.issue(req.user.userId, purpose);
      res.json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  verifyOtp: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const input = otpVerifySchema.parse(req.body);
      const { user } = await otpService.verify(input.email, input.code, input.purpose);
      await otpService.applyVerification(user.id, input.purpose);
      res.json({ success: true, data: { verified: true } });
    } catch (err) {
      next(err);
    }
  },

  // ---------- PASSWORD RESET ----------

  forgotPassword: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { email } = passwordResetRequestSchema.parse(req.body);
      const result = await passwordService.requestReset(email);
      res.json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  resetPassword: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const { token, newPassword } = passwordResetSchema.parse(req.body);
      const result = await passwordService.reset(token, newPassword);
      res.json({ success: true, data: result });
    } catch (err) {
      next(err);
    }
  },

  // ---------- GOOGLE OAUTH ----------

  googleStart: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const url = googleAuthService.buildAuthUrl(req.query.state as string | undefined);
      res.json({ success: true, data: { url } });
    } catch (err) {
      next(err);
    }
  },

  googleCallback: async (req: Request, res: Response, next: NextFunction) => {
    try {
      const code = req.query.code as string;
      if (!code) throw new UnauthorizedError('Missing OAuth code');

      const profile = await googleAuthService.exchangeCode(code);
      const result = await googleAuthService.upsertAndIssueTokens(profile, {
        userAgent: req.headers['user-agent'],
        ipAddress: req.ip,
      });

      // Redirect to frontend with tokens (or handle via cookie / postMessage)
      const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
      const redirect = `${appUrl}/auth/google/success?access=${encodeURIComponent(result.accessToken)}&refresh=${encodeURIComponent(result.refreshToken)}`;
      res.redirect(redirect);
    } catch (err) {
      next(err);
    }
  },
};
