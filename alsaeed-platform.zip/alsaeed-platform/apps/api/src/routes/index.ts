import { Router } from 'express';
import { authRouter } from './auth.routes';
import { coursesRouter } from './courses.routes';
import { usersRouter } from './users.routes';

export const apiRouter = Router();

apiRouter.use('/auth', authRouter);
apiRouter.use('/courses', coursesRouter);
apiRouter.use('/users', usersRouter);

// Placeholder for future routers (LMS, quizzes, payments, AI, etc.)
// apiRouter.use('/quizzes', quizzesRouter);
// apiRouter.use('/payments', paymentsRouter);
// apiRouter.use('/ai', aiRouter);
// apiRouter.use('/library', libraryRouter);
// apiRouter.use('/certificates', certificatesRouter);
// apiRouter.use('/consulting', consultingRouter);
// apiRouter.use('/corporate', corporateRouter);
// apiRouter.use('/admin', adminRouter);
