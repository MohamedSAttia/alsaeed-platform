import { Router } from 'express';
import { authController } from '../controllers/auth.controller';
import { authRateLimiter } from '../middleware/rate-limit.middleware';
import { requireAuth } from '../middleware/auth.middleware';

export const authRouter = Router();

// Basic auth
authRouter.post('/register', authRateLimiter, authController.register);
authRouter.post('/login', authRateLimiter, authController.login);
authRouter.post('/refresh', authController.refresh);
authRouter.post('/logout', requireAuth, authController.logout);
authRouter.get('/me', requireAuth, authController.me);

// OTP & email verification
authRouter.post('/otp/send', requireAuth, authRateLimiter, authController.sendOtp);
authRouter.post('/otp/verify', authRateLimiter, authController.verifyOtp);

// Password reset
authRouter.post('/forgot-password', authRateLimiter, authController.forgotPassword);
authRouter.post('/reset-password', authRateLimiter, authController.resetPassword);

// Google OAuth
authRouter.get('/google', authController.googleStart);
authRouter.get('/google/callback', authController.googleCallback);
