import { Router, Request, Response, NextFunction } from 'express';
import { prisma } from '@alsaeed/database';
import { requireAuth, requireRole } from '../middleware/auth.middleware';

export const coursesRouter = Router();

// Public: list published courses
coursesRouter.get('/', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const page = Math.max(1, Number(req.query.page) || 1);
    const pageSize = Math.min(50, Number(req.query.pageSize) || 12);
    const [items, total] = await Promise.all([
      prisma.course.findMany({
        where: { status: 'PUBLISHED' },
        skip: (page - 1) * pageSize,
        take: pageSize,
        orderBy: { createdAt: 'desc' },
        include: { category: true, instructor: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } } },
      }),
      prisma.course.count({ where: { status: 'PUBLISHED' } }),
    ]);
    res.json({
      success: true,
      data: items,
      meta: { page, pageSize, total, totalPages: Math.ceil(total / pageSize) },
    });
  } catch (err) {
    next(err);
  }
});

// Public: get single course by slug
coursesRouter.get('/:slug', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const course = await prisma.course.findUnique({
      where: { slug: req.params.slug },
      include: {
        category: true,
        instructor: { select: { id: true, firstName: true, lastName: true, avatarUrl: true } },
        chapters: { include: { lessons: true }, orderBy: { sortOrder: 'asc' } },
      },
    });
    if (!course) return res.status(404).json({ success: false, error: { code: 'NOT_FOUND', message: 'Course not found' } });
    res.json({ success: true, data: course });
  } catch (err) {
    next(err);
  }
});

// Protected: create course (instructor/admin)
coursesRouter.post('/', requireAuth, requireRole('INSTRUCTOR', 'ADMIN', 'SUPER_ADMIN'), async (req, res, next) => {
  try {
    // TODO: implement using courses.service.ts
    res.json({ success: true, data: { message: 'Not implemented yet' } });
  } catch (err) {
    next(err);
  }
});
