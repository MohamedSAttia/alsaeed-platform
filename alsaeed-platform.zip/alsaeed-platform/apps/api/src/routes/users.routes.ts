import { Router } from 'express';
import { requireAuth, requireRole } from '../middleware/auth.middleware';
import { prisma } from '@alsaeed/database';

export const usersRouter = Router();

usersRouter.get('/', requireAuth, requireRole('ADMIN', 'SUPER_ADMIN'), async (_req, res, next) => {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true, email: true, firstName: true, lastName: true,
        role: true, isActive: true, createdAt: true, lastLoginAt: true,
      },
      orderBy: { createdAt: 'desc' },
      take: 100,
    });
    res.json({ success: true, data: users });
  } catch (err) {
    next(err);
  }
});
