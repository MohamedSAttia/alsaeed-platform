import 'dotenv/config';
import { app } from './app';
import { env } from './config/env';
import { logger } from './utils/logger';
import { prisma } from '@alsaeed/database';

const PORT = env.API_PORT;

async function bootstrap() {
  try {
    await prisma.$connect();
    logger.info('✅ Database connected');

    app.listen(PORT, () => {
      logger.info(`🚀 API server running at http://localhost:${PORT}`);
      logger.info(`📖 Health check → http://localhost:${PORT}/health`);
    });
  } catch (err) {
    logger.error('❌ Failed to start server:', err);
    process.exit(1);
  }
}

// Graceful shutdown
const shutdown = async (signal: string) => {
  logger.info(`${signal} received, shutting down gracefully...`);
  await prisma.$disconnect();
  process.exit(0);
};

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

bootstrap();
