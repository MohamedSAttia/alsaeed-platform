import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { prisma } from '@alsaeed/database';
import { env } from '../config/env';
import { emailService } from './email.service';
import { NotFoundError, ValidationError } from '../utils/errors';

const RESET_TOKEN_TTL = '1h';

interface ResetTokenPayload {
  userId: string;
  purpose: 'password-reset';
}

export const passwordService = {
  requestReset: async (email: string) => {
    const user = await prisma.user.findUnique({ where: { email } });
    // Don't reveal whether email exists - return success either way
    if (!user) return { sent: true };

    const token = jwt.sign(
      { userId: user.id, purpose: 'password-reset' } satisfies ResetTokenPayload,
      env.JWT_ACCESS_SECRET,
      { expiresIn: RESET_TOKEN_TTL }
    );

    const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';
    const resetUrl = `${appUrl}/reset-password?token=${token}`;

    await emailService.sendPasswordReset(user.email, resetUrl, user.firstName);
    return { sent: true };
  },

  reset: async (token: string, newPassword: string) => {
    let payload: ResetTokenPayload;
    try {
      payload = jwt.verify(token, env.JWT_ACCESS_SECRET) as ResetTokenPayload;
    } catch {
      throw new ValidationError('Invalid or expired reset token');
    }

    if (payload.purpose !== 'password-reset') {
      throw new ValidationError('Invalid token purpose');
    }

    const user = await prisma.user.findUnique({ where: { id: payload.userId } });
    if (!user) throw new NotFoundError('User not found');

    const passwordHash = await bcrypt.hash(newPassword, env.BCRYPT_SALT_ROUNDS);

    await prisma.user.update({
      where: { id: user.id },
      data: { passwordHash },
    });

    // Revoke all existing sessions to force re-login everywhere
    await prisma.session.updateMany({
      where: { userId: user.id, revokedAt: null },
      data: { revokedAt: new Date() },
    });

    return { success: true };
  },
};
