import crypto from 'crypto';
import { prisma } from '@alsaeed/database';
import type { OtpPurpose } from '@alsaeed/database';
import { emailService } from './email.service';
import { ValidationError, NotFoundError } from '../utils/errors';

const OTP_EXPIRY_MINUTES = 10;
const MAX_ACTIVE_OTPS_PER_PURPOSE = 5;

const generateNumericCode = (length = 6): string => {
  let code = '';
  for (let i = 0; i < length; i++) {
    code += crypto.randomInt(0, 10).toString();
  }
  return code;
};

export const otpService = {
  /**
   * Generate, store, and email an OTP code to a user.
   */
  issue: async (userId: string, purpose: OtpPurpose) => {
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) throw new NotFoundError('User not found');

    // Invalidate any prior unused OTPs for this purpose to keep things clean
    await prisma.otpCode.updateMany({
      where: { userId, purpose, usedAt: null },
      data: { usedAt: new Date() },
    });

    const code = generateNumericCode(6);
    const expiresAt = new Date(Date.now() + OTP_EXPIRY_MINUTES * 60 * 1000);

    await prisma.otpCode.create({
      data: { userId, code, purpose, expiresAt },
    });

    await emailService.sendOtp(user.email, code, purpose, user.firstName);

    return { sent: true, expiresInMinutes: OTP_EXPIRY_MINUTES };
  },

  /**
   * Verify a submitted OTP code. Marks it as used on success.
   * Throws ValidationError on any failure.
   */
  verify: async (email: string, code: string, purpose: OtpPurpose) => {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user) throw new NotFoundError('User not found');

    const otp = await prisma.otpCode.findFirst({
      where: {
        userId: user.id,
        purpose,
        code,
        usedAt: null,
        expiresAt: { gt: new Date() },
      },
      orderBy: { createdAt: 'desc' },
    });

    if (!otp) throw new ValidationError('Invalid or expired code');

    await prisma.otpCode.update({
      where: { id: otp.id },
      data: { usedAt: new Date() },
    });

    return { user, verified: true };
  },

  /**
   * Apply the side-effects of a verified OTP based on its purpose.
   */
  applyVerification: async (userId: string, purpose: OtpPurpose) => {
    if (purpose === 'EMAIL_VERIFICATION') {
      await prisma.user.update({
        where: { id: userId },
        data: { emailVerified: true },
      });
    } else if (purpose === 'PHONE_VERIFICATION') {
      await prisma.user.update({
        where: { id: userId },
        data: { phoneVerified: true },
      });
    }
  },
};
