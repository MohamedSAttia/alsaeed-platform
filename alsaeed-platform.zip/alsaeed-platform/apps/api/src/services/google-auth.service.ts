import { prisma } from '@alsaeed/database';
import jwt, { SignOptions } from 'jsonwebtoken';
import { env } from '../config/env';
import { logger } from '../utils/logger';
import type { JwtPayload } from '../middleware/auth.middleware';
import { ValidationError } from '../utils/errors';

interface GoogleProfile {
  email: string;
  email_verified?: boolean;
  given_name?: string;
  family_name?: string;
  name?: string;
  picture?: string;
  sub: string; // Google user ID
}

const generateTokens = (user: { id: string; email: string; role: string }) => {
  const payload: JwtPayload = {
    userId: user.id,
    email: user.email,
    role: user.role as JwtPayload['role'],
  };
  const accessToken = jwt.sign(payload, env.JWT_ACCESS_SECRET, {
    expiresIn: env.JWT_ACCESS_EXPIRES_IN,
  } as SignOptions);
  const refreshToken = jwt.sign(payload, env.JWT_REFRESH_SECRET, {
    expiresIn: env.JWT_REFRESH_EXPIRES_IN,
  } as SignOptions);
  return { accessToken, refreshToken };
};

export const googleAuthService = {
  /**
   * Build the Google OAuth consent URL.
   */
  buildAuthUrl: (state?: string) => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const redirectUri = process.env.GOOGLE_REDIRECT_URI;
    if (!clientId || !redirectUri) {
      throw new ValidationError('Google OAuth not configured');
    }
    const params = new URLSearchParams({
      client_id: clientId,
      redirect_uri: redirectUri,
      response_type: 'code',
      scope: 'openid email profile',
      access_type: 'offline',
      prompt: 'consent',
      ...(state ? { state } : {}),
    });
    return `https://accounts.google.com/o/oauth2/v2/auth?${params}`;
  },

  /**
   * Exchange code for tokens and fetch user profile.
   */
  exchangeCode: async (code: string) => {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    const redirectUri = process.env.GOOGLE_REDIRECT_URI;
    if (!clientId || !clientSecret || !redirectUri) {
      throw new ValidationError('Google OAuth not configured');
    }

    // Exchange authorization code for access token
    const tokenRes = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: clientId,
        client_secret: clientSecret,
        redirect_uri: redirectUri,
        grant_type: 'authorization_code',
      }),
    });

    if (!tokenRes.ok) {
      const text = await tokenRes.text();
      logger.error('Google token exchange failed', { text });
      throw new ValidationError('Google authentication failed');
    }

    const tokenData = (await tokenRes.json()) as { access_token: string; id_token: string };

    // Fetch user profile
    const profileRes = await fetch('https://www.googleapis.com/oauth2/v3/userinfo', {
      headers: { Authorization: `Bearer ${tokenData.access_token}` },
    });
    if (!profileRes.ok) throw new ValidationError('Failed to fetch Google profile');

    const profile = (await profileRes.json()) as GoogleProfile;
    return profile;
  },

  /**
   * Find-or-create a user from a Google profile and issue our own JWT pair.
   */
  upsertAndIssueTokens: async (profile: GoogleProfile, meta: { userAgent?: string; ipAddress?: string }) => {
    if (!profile.email) throw new ValidationError('Google account has no email');

    let user = await prisma.user.findUnique({ where: { email: profile.email } });

    if (!user) {
      user = await prisma.user.create({
        data: {
          email: profile.email,
          firstName: profile.given_name || profile.name?.split(' ')[0] || 'User',
          lastName: profile.family_name || profile.name?.split(' ').slice(1).join(' ') || '',
          avatarUrl: profile.picture,
          authProvider: 'GOOGLE',
          emailVerified: profile.email_verified ?? true,
        },
      });
    } else if (!user.avatarUrl && profile.picture) {
      user = await prisma.user.update({
        where: { id: user.id },
        data: { avatarUrl: profile.picture, emailVerified: true },
      });
    }

    const tokens = generateTokens(user);
    await prisma.session.create({
      data: {
        userId: user.id,
        refreshToken: tokens.refreshToken,
        userAgent: meta.userAgent,
        ipAddress: meta.ipAddress,
        expiresAt: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000),
      },
    });

    await prisma.user.update({
      where: { id: user.id },
      data: { lastLoginAt: new Date() },
    });

    const { passwordHash: _ph, ...safeUser } = user;
    return { user: safeUser, ...tokens };
  },
};
