import nodemailer from 'nodemailer';
import { logger } from '../utils/logger';

const transporter = nodemailer.createTransport({
  host: process.env.SMTP_HOST,
  port: Number(process.env.SMTP_PORT) || 587,
  secure: false,
  auth: {
    user: process.env.SMTP_USER,
    pass: process.env.SMTP_PASS,
  },
});

const FROM = process.env.SMTP_FROM || 'Al Saeed ETC <noreply@alsaeed-etc.com>';

interface SendEmailParams {
  to: string;
  subject: string;
  html: string;
  text?: string;
}

const baseTemplate = (content: string) => `
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <style>
    body { font-family: 'Cairo', Arial, sans-serif; background: #F4F6FB; margin: 0; padding: 40px 20px; }
    .container { max-width: 560px; margin: 0 auto; background: #fff; border-radius: 16px; overflow: hidden; box-shadow: 0 6px 28px rgba(13,27,62,.14); }
    .header { background: linear-gradient(135deg, #0D1B3E, #06101f); padding: 32px; text-align: center; }
    .header h1 { color: #C9A84C; margin: 0; font-size: 24px; font-weight: 800; }
    .body { padding: 32px; color: #2D3548; line-height: 1.7; font-size: 15px; }
    .otp-box { background: #F1F3F7; border: 2px dashed #C9A84C; border-radius: 12px; padding: 20px; text-align: center; margin: 24px 0; }
    .otp-code { font-family: 'Courier New', monospace; font-size: 32px; font-weight: 700; color: #0D1B3E; letter-spacing: 8px; }
    .btn { display: inline-block; background: #0B6E4F; color: #fff !important; padding: 12px 32px; border-radius: 10px; text-decoration: none; font-weight: 600; }
    .footer { background: #F1F3F7; padding: 20px; text-align: center; color: #5A6478; font-size: 12px; }
  </style>
</head>
<body>
  <div class="container">
    <div class="header"><h1>Al Saeed ETC</h1></div>
    <div class="body">${content}</div>
    <div class="footer">© ${new Date().getFullYear()} Al Saeed Education, Training & Consultancy</div>
  </div>
</body>
</html>`;

export const emailService = {
  send: async ({ to, subject, html, text }: SendEmailParams) => {
    if (!process.env.SMTP_USER) {
      // Dev mode - just log it
      logger.info(`📧 [DEV] Email to ${to} | ${subject}`);
      logger.info(`Body: ${text || html.replace(/<[^>]+>/g, '').slice(0, 200)}`);
      return { messageId: 'dev-mode' };
    }

    try {
      const info = await transporter.sendMail({ from: FROM, to, subject, html, text });
      logger.info(`📧 Sent to ${to}: ${info.messageId}`);
      return info;
    } catch (err) {
      logger.error('Email send failed:', err);
      throw err;
    }
  },

  sendOtp: async (to: string, code: string, purpose: string, name?: string) => {
    const purposeText: Record<string, string> = {
      EMAIL_VERIFICATION: 'تأكيد بريدك الإلكتروني',
      PHONE_VERIFICATION: 'تأكيد رقم هاتفك',
      PASSWORD_RESET: 'إعادة تعيين كلمة المرور',
      TWO_FACTOR: 'تسجيل الدخول الآمن',
    };
    const greeting = name ? `أهلاً ${name}،` : 'أهلاً بك،';
    const html = baseTemplate(`
      <p>${greeting}</p>
      <p>استخدم الرمز التالي لـ <strong>${purposeText[purpose] || purpose}</strong>:</p>
      <div class="otp-box"><div class="otp-code">${code}</div></div>
      <p style="color:#5A6478;font-size:13px;">⏱️ هذا الرمز صالح لمدة 10 دقائق فقط.</p>
      <p style="color:#5A6478;font-size:13px;">إن لم تطلب هذا الرمز، يمكنك تجاهل هذه الرسالة بأمان.</p>
    `);
    return emailService.send({
      to,
      subject: `${purposeText[purpose] || 'رمز التحقق'} — ${code}`,
      html,
      text: `Your verification code: ${code}`,
    });
  },

  sendPasswordReset: async (to: string, resetUrl: string, name?: string) => {
    const html = baseTemplate(`
      <p>${name ? `أهلاً ${name}،` : 'أهلاً بك،'}</p>
      <p>تلقينا طلباً لإعادة تعيين كلمة المرور الخاصة بحسابك. اضغط على الزر أدناه لإكمال العملية:</p>
      <p style="text-align:center;margin:24px 0;">
        <a href="${resetUrl}" class="btn">إعادة تعيين كلمة المرور</a>
      </p>
      <p style="color:#5A6478;font-size:13px;">⏱️ هذا الرابط صالح لمدة ساعة واحدة.</p>
      <p style="color:#5A6478;font-size:13px;">إن لم تطلب ذلك، يمكنك تجاهل هذه الرسالة وكلمة مرورك ستبقى كما هي.</p>
    `);
    return emailService.send({ to, subject: 'إعادة تعيين كلمة المرور', html });
  },

  sendWelcome: async (to: string, name: string) => {
    const html = baseTemplate(`
      <p>أهلاً ${name}! 🎉</p>
      <p>سعداء بانضمامك إلى منصة <strong>Al Saeed ETC</strong>. حسابك جاهز الآن، ويمكنك:</p>
      <ul>
        <li>تصفح أكثر من 100 دورة معتمدة</li>
        <li>التدريب على محاكاة شهادات PMP و GRC و NEBOSH</li>
        <li>الوصول إلى المساعد الذكي AI Tutor</li>
        <li>الحصول على شهادات إنجاز معتمدة</li>
      </ul>
      <p style="text-align:center;margin:24px 0;">
        <a href="${process.env.NEXT_PUBLIC_APP_URL || 'https://alsaeed-etc.com'}" class="btn">ابدأ رحلتك التعليمية</a>
      </p>
    `);
    return emailService.send({ to, subject: 'مرحباً بك في Al Saeed ETC 🎉', html });
  },
};
