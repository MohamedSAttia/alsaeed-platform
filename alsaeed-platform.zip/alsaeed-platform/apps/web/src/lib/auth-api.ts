import { apiClient } from './api-client';

interface AuthResponse {
  user: {
    id: string;
    email: string;
    firstName: string;
    lastName: string;
    role: string;
    avatarUrl?: string | null;
    emailVerified: boolean;
  };
  accessToken: string;
  refreshToken: string;
}

export const authApi = {
  register: (data: {
    email: string;
    password: string;
    firstName: string;
    lastName: string;
    phone?: string;
  }) => apiClient.post<{ success: true; data: AuthResponse }>('/auth/register', data).then((r) => r.data.data),

  login: (data: { email: string; password: string }) =>
    apiClient.post<{ success: true; data: AuthResponse }>('/auth/login', data).then((r) => r.data.data),

  logout: (refreshToken: string) =>
    apiClient.post('/auth/logout', { refreshToken }).then((r) => r.data),

  me: () => apiClient.get('/auth/me').then((r) => r.data.data),

  verifyOtp: (data: { email: string; code: string; purpose: string }) =>
    apiClient.post('/auth/otp/verify', data).then((r) => r.data),

  resendOtp: (purpose = 'EMAIL_VERIFICATION') =>
    apiClient.post('/auth/otp/send', { purpose }).then((r) => r.data),

  forgotPassword: (email: string) =>
    apiClient.post('/auth/forgot-password', { email }).then((r) => r.data),

  resetPassword: (token: string, newPassword: string) =>
    apiClient.post('/auth/reset-password', { token, newPassword }).then((r) => r.data),

  googleStart: () =>
    apiClient.get<{ success: true; data: { url: string } }>('/auth/google').then((r) => r.data.data.url),
};
