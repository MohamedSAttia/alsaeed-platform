import type { Metadata } from 'next';
import { Cairo, Poppins } from 'next/font/google';
import { Providers } from './providers';
import '../styles/globals.css';

const cairo = Cairo({ subsets: ['arabic', 'latin'], variable: '--font-cairo', display: 'swap' });
const poppins = Poppins({ subsets: ['latin'], weight: ['300', '400', '600', '700', '800'], variable: '--font-poppins', display: 'swap' });

export const metadata: Metadata = {
  title: 'Al Saeed ETC — منصة التعليم والتدريب',
  description: 'منصة Al Saeed للتعليم والتدريب والاستشارات المهنية',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="ar" dir="rtl" className={`${cairo.variable} ${poppins.variable}`}>
      <body>
        <Providers>{children}</Providers>
      </body>
    </html>
  );
}
