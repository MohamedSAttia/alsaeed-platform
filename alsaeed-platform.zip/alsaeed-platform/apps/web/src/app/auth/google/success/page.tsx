'use client';

import { useEffect } from 'react';
import { useRouter, useSearchParams } from 'next/navigation';
import { useAuthStore } from '@/store/auth.store';
import { authApi } from '@/lib/auth-api';

export default function GoogleSuccessPage() {
  const router = useRouter();
  const params = useSearchParams();
  const setAuth = useAuthStore((s) => s.setAuth);

  useEffect(() => {
    const access = params.get('access');
    const refresh = params.get('refresh');
    if (!access || !refresh) {
      router.replace('/login');
      return;
    }

    localStorage.setItem('accessToken', access);
    localStorage.setItem('refreshToken', refresh);

    authApi
      .me()
      .then((user) => {
        setAuth({ user, accessToken: access, refreshToken: refresh });
        router.replace('/dashboard');
      })
      .catch(() => router.replace('/login'));
  }, [params, router, setAuth]);

  return (
    <main className="min-h-screen flex items-center justify-center bg-navy-dark">
      <div className="text-center text-white">
        <div className="w-12 h-12 border-4 border-gold border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p>جاري إكمال تسجيل الدخول...</p>
      </div>
    </main>
  );
}
