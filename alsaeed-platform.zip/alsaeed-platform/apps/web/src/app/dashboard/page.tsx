'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { useAuthStore } from '@/store/auth.store';
import { authApi } from '@/lib/auth-api';

export default function DashboardPage() {
  const router = useRouter();
  const { user, clearAuth } = useAuthStore();

  useEffect(() => {
    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('accessToken');
      if (!token) router.replace('/login');
    }
  }, [router]);

  const handleLogout = async () => {
    const refresh = localStorage.getItem('refreshToken');
    if (refresh) await authApi.logout(refresh).catch(() => {});
    clearAuth();
    router.push('/login');
  };

  if (!user) {
    return (
      <main className="min-h-screen flex items-center justify-center">
        <div className="w-12 h-12 border-4 border-green border-t-transparent rounded-full animate-spin" />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-gray-50">
      <header className="bg-navy-dark text-white px-6 py-4 flex items-center justify-between">
        <h1 className="text-xl font-bold">
          <span className="text-gold">Al Saeed</span> Dashboard
        </h1>
        <div className="flex items-center gap-4">
          <span className="text-sm">أهلاً، {user.firstName}</span>
          <button
            onClick={handleLogout}
            className="text-sm px-4 py-1.5 border border-white/20 rounded-lg hover:bg-white/10 transition"
          >
            خروج
          </button>
        </div>
      </header>

      <div className="max-w-6xl mx-auto p-6">
        <div className="bg-white rounded-2xl shadow-s2 p-8">
          <h2 className="text-2xl font-bold text-navy mb-2">مرحباً بك في لوحة التحكم 🎉</h2>
          <p className="text-gray-600 mb-6">حسابك جاهز. ابدأ في استكشاف الدورات والمحتوى.</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="p-6 bg-gradient-to-br from-green to-green-bright text-white rounded-xl">
              <div className="text-3xl mb-2">📚</div>
              <h3 className="font-semibold mb-1">الدورات</h3>
              <p className="text-sm text-white/80">تصفح الدورات المتاحة</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-gold to-gold-light text-navy-dark rounded-xl">
              <div className="text-3xl mb-2">🎯</div>
              <h3 className="font-semibold mb-1">المحاكاة</h3>
              <p className="text-sm text-navy/80">تدرّب على شهادات PMP و GRC</p>
            </div>
            <div className="p-6 bg-gradient-to-br from-purple to-pink-500 text-white rounded-xl">
              <div className="text-3xl mb-2">🤖</div>
              <h3 className="font-semibold mb-1">AI Tutor</h3>
              <p className="text-sm text-white/80">مساعد ذكي للتعلم</p>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}
