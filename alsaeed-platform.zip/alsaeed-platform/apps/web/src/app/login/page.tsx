'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { loginSchema, type LoginInput } from '@alsaeed/shared';
import { authApi } from '@/lib/auth-api';
import { useAuthStore } from '@/store/auth.store';

export default function LoginPage() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginInput>({ resolver: zodResolver(loginSchema) });

  const onSubmit = async (data: LoginInput) => {
    setServerError(null);
    try {
      const result = await authApi.login(data);
      setAuth(result);
      router.push('/dashboard');
    } catch (err: any) {
      setServerError(err?.response?.data?.error?.message || 'حدث خطأ. حاول مرة أخرى.');
    }
  };

  const handleGoogle = async () => {
    try {
      const url = await authApi.googleStart();
      window.location.href = url;
    } catch (err) {
      setServerError('Google sign-in not configured yet.');
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-navy-dark via-navy to-navy-light px-4 py-12">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-s3 p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-navy mb-2">أهلاً بعودتك 👋</h1>
            <p className="text-sm text-gray-600">سجّل دخولك لمتابعة رحلتك التعليمية</p>
          </div>

          {serverError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
              {serverError}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
              <input
                type="email"
                {...register('email')}
                className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none transition"
                placeholder="you@example.com"
              />
              {errors.email && <p className="text-red-600 text-xs mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور</label>
              <input
                type="password"
                {...register('password')}
                className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none transition"
                placeholder="••••••••"
              />
              {errors.password && <p className="text-red-600 text-xs mt-1">{errors.password.message}</p>}
            </div>

            <div className="flex justify-end">
              <Link href="/forgot-password" className="text-sm text-green hover:text-green-bright">
                نسيت كلمة المرور؟
              </Link>
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-gradient-to-r from-green to-green-bright text-white font-semibold rounded-lg hover:opacity-90 disabled:opacity-50 transition"
            >
              {isSubmitting ? 'جاري الدخول...' : 'دخول'}
            </button>
          </form>

          <div className="my-6 flex items-center gap-3">
            <div className="flex-1 h-px bg-gray-200" />
            <span className="text-xs text-gray-400">أو</span>
            <div className="flex-1 h-px bg-gray-200" />
          </div>

          <button
            onClick={handleGoogle}
            className="w-full py-3 bg-white border-2 border-gray-200 rounded-lg font-medium hover:border-gray-300 transition flex items-center justify-center gap-3"
          >
            <svg className="w-5 h-5" viewBox="0 0 24 24">
              <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
              <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
              <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
              <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
            </svg>
            الدخول بحساب Google
          </button>

          <p className="text-center text-sm text-gray-600 mt-6">
            ليس لديك حساب؟{' '}
            <Link href="/register" className="text-green font-semibold hover:text-green-bright">
              أنشئ حساباً جديداً
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
