'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { registerSchema, type RegisterInput } from '@alsaeed/shared';
import { authApi } from '@/lib/auth-api';
import { useAuthStore } from '@/store/auth.store';

export default function RegisterPage() {
  const router = useRouter();
  const setAuth = useAuthStore((s) => s.setAuth);
  const [serverError, setServerError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<RegisterInput>({ resolver: zodResolver(registerSchema) });

  const onSubmit = async (data: RegisterInput) => {
    setServerError(null);
    try {
      const result = await authApi.register(data);
      setAuth(result);
      router.push('/verify-email');
    } catch (err: any) {
      setServerError(err?.response?.data?.error?.message || 'حدث خطأ. حاول مرة أخرى.');
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-navy-dark via-navy to-navy-light px-4 py-12">
      <div className="w-full max-w-md">
        <div className="bg-white rounded-2xl shadow-s3 p-8">
          <div className="text-center mb-8">
            <h1 className="text-2xl font-bold text-navy mb-2">أنشئ حسابك المجاني 🚀</h1>
            <p className="text-sm text-gray-600">انضم إلى آلاف المتعلمين حول العالم</p>
          </div>

          {serverError && (
            <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
              {serverError}
            </div>
          )}

          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">الاسم الأول</label>
                <input
                  {...register('firstName')}
                  className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none"
                />
                {errors.firstName && <p className="text-red-600 text-xs mt-1">{errors.firstName.message}</p>}
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">اسم العائلة</label>
                <input
                  {...register('lastName')}
                  className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none"
                />
                {errors.lastName && <p className="text-red-600 text-xs mt-1">{errors.lastName.message}</p>}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
              <input
                type="email"
                {...register('email')}
                className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none"
              />
              {errors.email && <p className="text-red-600 text-xs mt-1">{errors.email.message}</p>}
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">كلمة المرور</label>
              <input
                type="password"
                {...register('password')}
                className="w-full px-4 py-2.5 rounded-lg border border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none"
                placeholder="8 أحرف على الأقل، حرف كبير، صغير، ورقم"
              />
              {errors.password && <p className="text-red-600 text-xs mt-1">{errors.password.message}</p>}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="w-full py-3 bg-gradient-to-r from-green to-green-bright text-white font-semibold rounded-lg hover:opacity-90 disabled:opacity-50 transition"
            >
              {isSubmitting ? 'جاري إنشاء الحساب...' : 'إنشاء حساب'}
            </button>
          </form>

          <p className="text-center text-sm text-gray-600 mt-6">
            لديك حساب بالفعل؟{' '}
            <Link href="/login" className="text-green font-semibold hover:text-green-bright">
              سجّل دخولك
            </Link>
          </p>
        </div>
      </div>
    </main>
  );
}
