'use client';

import { useState, useRef, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { authApi } from '@/lib/auth-api';
import { useAuthStore } from '@/store/auth.store';

export default function VerifyEmailPage() {
  const router = useRouter();
  const user = useAuthStore((s) => s.user);
  const [code, setCode] = useState(['', '', '', '', '', '']);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);
  const [resendCooldown, setResendCooldown] = useState(0);
  const inputs = useRef<(HTMLInputElement | null)[]>([]);

  useEffect(() => {
    if (resendCooldown <= 0) return;
    const t = setTimeout(() => setResendCooldown((c) => c - 1), 1000);
    return () => clearTimeout(t);
  }, [resendCooldown]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d?$/.test(value)) return;
    const newCode = [...code];
    newCode[index] = value;
    setCode(newCode);
    if (value && index < 5) inputs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === 'Backspace' && !code[index] && index > 0) {
      inputs.current[index - 1]?.focus();
    }
  };

  const handlePaste = (e: React.ClipboardEvent) => {
    e.preventDefault();
    const pasted = e.clipboardData.getData('text').replace(/\D/g, '').slice(0, 6);
    if (pasted.length === 6) {
      setCode(pasted.split(''));
      inputs.current[5]?.focus();
    }
  };

  const handleSubmit = async () => {
    setError(null);
    if (code.some((c) => !c)) return setError('من فضلك أدخل الرمز كاملاً');
    if (!user?.email) return setError('لم نتعرف على حسابك. سجّل دخولك أولاً.');

    try {
      await authApi.verifyOtp({
        email: user.email,
        code: code.join(''),
        purpose: 'EMAIL_VERIFICATION',
      });
      setSuccess(true);
      setTimeout(() => router.push('/dashboard'), 1500);
    } catch (err: any) {
      setError(err?.response?.data?.error?.message || 'الرمز غير صحيح أو منتهي الصلاحية');
    }
  };

  const handleResend = async () => {
    setError(null);
    try {
      await authApi.resendOtp('EMAIL_VERIFICATION');
      setResendCooldown(60);
    } catch (err: any) {
      setError('فشل إرسال الرمز');
    }
  };

  return (
    <main className="min-h-screen flex items-center justify-center bg-gradient-to-br from-navy-dark via-navy to-navy-light px-4">
      <div className="w-full max-w-md bg-white rounded-2xl shadow-s3 p-8">
        <div className="text-center mb-8">
          <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-gradient-to-br from-gold to-gold-light flex items-center justify-center text-3xl">
            📧
          </div>
          <h1 className="text-2xl font-bold text-navy mb-2">تأكيد بريدك الإلكتروني</h1>
          <p className="text-sm text-gray-600">
            أرسلنا رمزاً مكوناً من 6 أرقام إلى{' '}
            <span className="font-semibold text-navy">{user?.email || 'بريدك'}</span>
          </p>
        </div>

        {success && (
          <div className="mb-4 p-3 bg-green-50 border border-green-200 text-green-700 rounded-lg text-sm text-center">
            ✅ تم التحقق! جاري تحويلك...
          </div>
        )}

        {error && (
          <div className="mb-4 p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm text-center">
            {error}
          </div>
        )}

        <div className="flex gap-2 justify-center mb-6" dir="ltr" onPaste={handlePaste}>
          {code.map((digit, i) => (
            <input
              key={i}
              ref={(el) => (inputs.current[i] = el)}
              type="text"
              inputMode="numeric"
              maxLength={1}
              value={digit}
              onChange={(e) => handleChange(i, e.target.value)}
              onKeyDown={(e) => handleKeyDown(i, e)}
              className="w-12 h-14 text-center text-2xl font-bold rounded-lg border-2 border-gray-300 focus:border-green focus:ring-2 focus:ring-green/20 outline-none"
            />
          ))}
        </div>

        <button
          onClick={handleSubmit}
          disabled={success}
          className="w-full py-3 bg-gradient-to-r from-green to-green-bright text-white font-semibold rounded-lg hover:opacity-90 disabled:opacity-50 transition mb-4"
        >
          تحقق
        </button>

        <p className="text-center text-sm text-gray-600">
          لم يصلك الرمز؟{' '}
          <button
            onClick={handleResend}
            disabled={resendCooldown > 0}
            className="text-green font-semibold hover:text-green-bright disabled:text-gray-400 disabled:cursor-not-allowed"
          >
            {resendCooldown > 0 ? `إعادة الإرسال (${resendCooldown}s)` : 'إعادة الإرسال'}
          </button>
        </p>
      </div>
    </main>
  );
}
