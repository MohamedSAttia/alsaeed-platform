export default function HomePage() {
  return (
    <main className="min-h-screen flex items-center justify-center bg-navy-dark text-white">
      <div className="text-center px-6">
        <h1 className="text-4xl md:text-6xl font-bold mb-4">
          <span className="text-gold">Al Saeed</span> ETC
        </h1>
        <p className="text-lg text-gray-300 mb-8">
          منصة التعليم والتدريب والاستشارات
        </p>
        <p className="text-sm text-gray-500">
          🏗️ The platform is under construction. Frontend scaffolding ready.
        </p>
      </div>
    </main>
  );
}
