import type { Config } from 'tailwindcss';

const config: Config = {
  content: ['./src/**/*.{js,ts,jsx,tsx,mdx}'],
  theme: {
    extend: {
      colors: {
        // Brand palette extracted from existing prototype
        navy: { DEFAULT: '#0D1B3E', dark: '#06101f', light: '#1a3060' },
        green: { DEFAULT: '#0B6E4F', light: '#0D9B6F', bright: '#12BF87' },
        gold: { DEFAULT: '#C9A84C', light: '#E8C96A' },
        purple: '#7B2D8B',
      },
      fontFamily: {
        sans: ['var(--font-cairo)', 'system-ui', 'sans-serif'],
        display: ['var(--font-poppins)', 'system-ui', 'sans-serif'],
      },
      borderRadius: {
        DEFAULT: '12px',
        lg: '20px',
        xl: '28px',
      },
      boxShadow: {
        s1: '0 2px 12px rgba(13,27,62,.08)',
        s2: '0 6px 28px rgba(13,27,62,.14)',
        s3: '0 16px 56px rgba(13,27,62,.22)',
      },
    },
  },
  plugins: [],
};

export default config;
