# API Reference

Base URL: `http://localhost:4000/api/v1`
All responses follow this shape:
```json
// Success
{ "success": true, "data": { ... }, "meta": { ... } }
// Error
{ "success": false, "error": { "code": "ERROR_CODE", "message": "...", "details": {} } }
```

---

## 🔐 Authentication

### POST `/auth/register`
Create a new user account. Auto-sends OTP + welcome email.

**Body:**
```json
{
  "email": "user@example.com",
  "password": "Pass1234",
  "firstName": "Ahmed",
  "lastName": "Ali",
  "phone": "+201234567890",
  "preferredLang": "ar"
}
```

**Response:** `201 Created`
```json
{
  "success": true,
  "data": {
    "user": { "id": "...", "email": "...", "firstName": "...", "role": "STUDENT", "emailVerified": false },
    "accessToken": "eyJ...",
    "refreshToken": "eyJ..."
  }
}
```

---

### POST `/auth/login`
**Body:** `{ "email": "...", "password": "..." }`
Returns same shape as register.

---

### POST `/auth/refresh`
**Body:** `{ "refreshToken": "..." }`
**Response:** `{ accessToken, refreshToken }` (rotates the refresh token).

---

### POST `/auth/logout`
**Auth required.** **Body:** `{ "refreshToken": "..." }`
Revokes the session.

---

### GET `/auth/me`
**Auth required.** Returns the current user (without password hash).

---

### POST `/auth/otp/send`
**Auth required.** Sends a fresh OTP code.
**Body:** `{ "purpose": "EMAIL_VERIFICATION" }` (or `PHONE_VERIFICATION`, `PASSWORD_RESET`, `TWO_FACTOR`)

---

### POST `/auth/otp/verify`
**Body:**
```json
{ "email": "...", "code": "123456", "purpose": "EMAIL_VERIFICATION" }
```
Marks the user's email/phone as verified depending on the purpose.

---

### POST `/auth/forgot-password`
**Body:** `{ "email": "..." }`
Always responds 200 OK (does not reveal whether the email exists). Sends a reset link if the user exists.

---

### POST `/auth/reset-password`
**Body:** `{ "token": "<from email link>", "newPassword": "..." }`
Resets the password and revokes all existing sessions.

---

### GET `/auth/google`
Returns the Google consent URL for the frontend to redirect to.
**Response:** `{ "url": "https://accounts.google.com/..." }`

---

### GET `/auth/google/callback`
Used by Google after consent. Redirects to the frontend at:
`${NEXT_PUBLIC_APP_URL}/auth/google/success?access=...&refresh=...`

---

## 📚 Courses

### GET `/courses?page=1&pageSize=12`
Public. Lists all `PUBLISHED` courses with pagination.

### GET `/courses/:slug`
Public. Returns one course with its chapters and lessons.

### POST `/courses`
**Auth + Role: INSTRUCTOR/ADMIN/SUPER_ADMIN.** Create a course. _(Not yet implemented)_

---

## 👥 Users

### GET `/users`
**Auth + Role: ADMIN/SUPER_ADMIN.** Lists the most recent 100 users.

---

## 🚧 Coming Soon

- `/quizzes/*` — quiz engine + simulation
- `/payments/*` — Stripe + Paymob webhooks
- `/ai/*` — AI tutor + summarization
- `/library/*` — digital library
- `/certificates/*` — certificate generation + QR verification
- `/consulting/*` — consultation requests
- `/corporate/*` — B2B team management
- `/admin/*` — admin analytics

---

## 🧪 Quick Test (curl)

```bash
# Register
curl -X POST http://localhost:4000/api/v1/auth/register \
  -H "Content-Type: application/json" \
  -d '{"email":"test@example.com","password":"Test1234","firstName":"Test","lastName":"User"}'

# Save the accessToken from the response
TOKEN="eyJ..."

# Get me
curl http://localhost:4000/api/v1/auth/me \
  -H "Authorization: Bearer $TOKEN"

# List courses (no auth)
curl http://localhost:4000/api/v1/courses
```
