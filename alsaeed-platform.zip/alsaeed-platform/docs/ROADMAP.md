# 🗺️ Development Roadmap

## Status: Foundation Complete ✅

The scaffolding (monorepo, database schema, auth module, frontend bootstrap) is **done**. From here, you build feature modules one at a time.

---

## 📅 Suggested 6-Month Plan (Solo Developer)

### Month 1 — Auth + Course Basics
- [x] Email/password auth with JWT + refresh rotation
- [x] OTP email verification
- [x] Password reset flow
- [x] Google OAuth
- [x] Login / Register / Verify pages
- [ ] Phone OTP via Twilio/local SMS provider
- [ ] User profile page (avatar upload, language preference)
- [ ] Course CRUD (admin)
- [ ] Course list page + detail page (public)
- [ ] Enrollment endpoint + course player skeleton

### Month 2 — LMS + Content
- [ ] Video player component (HLS/MP4 + resume position)
- [ ] Lesson progress tracking endpoint + auto-save
- [ ] Chapter navigation in course player
- [ ] Lesson notes (with video timestamps)
- [ ] Course attachments (download endpoint)
- [ ] Certificates engine (pdf-lib + QR codes)
- [ ] Course reviews + ratings

### Month 3 — Quiz Engine + Library
- [ ] Quiz CRUD (admin) with question banks
- [ ] PMP / RMP / GRC question seed data
- [ ] Quiz attempt flow with timer
- [ ] Domain analytics (per topic correctness)
- [ ] Library upload + browsing
- [ ] Search across courses + library
- [ ] Favorites system

### Month 4 — Payments + Subscriptions
- [ ] Stripe integration (checkout + webhooks)
- [ ] Paymob integration (MENA payments)
- [ ] Subscription plans + auto-renewal
- [ ] Coupons + discounts
- [ ] Invoice generation (PDF)
- [ ] Apple Pay (via Stripe)

### Month 5 — AI + Analytics
- [ ] AI Assistant (OpenAI chat with streaming)
- [ ] Lesson summarization endpoint
- [ ] Quiz answer explanations
- [ ] Learning recommendation engine
- [ ] Student progress analytics
- [ ] Admin dashboard with charts (recharts)
- [ ] Export reports (PDF/Excel)

### Month 6 — Corporate + Polish
- [ ] Organization management
- [ ] Team invite flow
- [ ] Corporate analytics (per-employee progress)
- [ ] Consulting request flow
- [ ] Multi-language UI (i18next with 7 languages)
- [ ] SEO optimization (meta, sitemap, OG tags)
- [ ] Performance audit + Lighthouse > 90
- [ ] Production deployment to Vercel + Railway

---

## 🎯 MVP Definition (What You Need to Launch)

A realistic MVP for **soft-launch** in 8-10 weeks:

1. ✅ Auth (done)
2. Courses + Player + Enrollment
3. One paid plan via Stripe
4. Basic certificates
5. 5-10 seed courses to fill the catalog

**Skip for MVP** (add after launch based on demand):
- Multi-language UI (start with Arabic only)
- AI features (start with manual summaries)
- Corporate B2B
- Mobile app
- Advanced analytics

---

## 📏 How to Build Each Module

For every new feature, follow this sequence:

1. **Schema** — add/modify Prisma models, run `npm run db:push`
2. **Validators** — add zod schemas to `packages/shared/src/validators/`
3. **Service** — write business logic in `apps/api/src/services/{feature}.service.ts`
4. **Controller** — wire HTTP layer in `apps/api/src/controllers/`
5. **Routes** — register in `apps/api/src/routes/`
6. **API client** — add methods in `apps/web/src/lib/{feature}-api.ts`
7. **UI** — build pages/components in `apps/web/src/app/{feature}/`
8. **Test** — manually with curl + frontend, then add automated tests

---

## ⚠️ Common Pitfalls to Avoid

- **Don't skip the validators** — they prevent 80% of bugs.
- **Don't store secrets in client code** — anything in `apps/web/` is public.
- **Don't run `db:push` in production** — use `db:migrate:deploy` instead.
- **Don't forget Supabase RLS** — if using Supabase, every table needs row-level security policies.
- **Don't build mobile first** — get web stable before forking effort to React Native.
- **Don't perfect UI before logic** — ship ugly-but-functional, then iterate.

---

## 🆘 When You Get Stuck

- **TypeScript errors** → run `npm run typecheck` from root and fix one workspace at a time.
- **Prisma errors** → `npm run db:generate` after every schema change.
- **CORS issues** → check `CORS_ORIGIN` in `.env` matches your frontend URL.
- **JWT expired** → the auto-refresh in `api-client.ts` should handle it; if not, check secrets match.
- **Migrations conflict** → `npm run db:reset` (dev only — wipes data).

Build small, test often, ship steady. Good luck. 🚀
